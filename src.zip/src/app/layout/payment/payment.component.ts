import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class PaymentComponent implements OnInit {
  availability: boolean = false;
  pincode: any;
  pincodes: any = [
    { pincode: 560093, price: 50 },
    { pincode: 560092, price: 150 },
    { pincode: 560091, price: 100 },
    { pincode: 560060, price: 50 },
    { pincode: 560090, price: 50 },
  ]
  constructor() { }

  ngOnInit() {
    window.scroll(0, 0);
  }

  checkAvailability() {
    console.log(this.pincode);
    for (var i = 0; i < this.pincodes.length; i++) {
      if (this.pincodes[i].pincode == this.pincode) {
        this.availability = true;
        break;
      } else {
        this.availability = false;
      }
    }
  }

}
